'use strict';

import React from 'react';

let Title = () => {
  return <div className='title auto-hidden'>
          <h1><strong>Magic</strong>Playlist /</h1>
          <h3>Get the playlist of your dreams based on a song.</h3>
        </div>;
};

export default Title;
