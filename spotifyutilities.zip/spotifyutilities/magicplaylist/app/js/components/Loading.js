'use strict';

import React from 'react';

let Loading = () => {
  return <img className='loading' src='img/audio.svg'/>;
};

export default Loading;
