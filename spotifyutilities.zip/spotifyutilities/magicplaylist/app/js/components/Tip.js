'use strict';

import React, {Component} from 'react';

let Tip = () => {
  return <div className='tip'>
            <span>Tip: Type a song + artist for better results.</span>
            <span>(ex: Billie Jean, Michael Jackson)</span>
          </div>;
};

export default Tip;
